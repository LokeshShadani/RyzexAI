
const chatBox = document.getElementById("chat-box");

function sendMessage() {
  const input = document.getElementById("message");
  const message = input.value;
  if (!message) return;

  appendMessage("You", message);
  input.value = "";

  fetch("/chat", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ message }),
  })
    .then((res) => res.json())
    .then((data) => {
      appendMessage("Ryzex", data.reply);
    });
}

function appendMessage(sender, message) {
  const msg = document.createElement("div");
  msg.innerHTML = `<strong>${sender}:</strong> ${message}`;
  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

// Voice input
function startVoice() {
  const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
  recognition.lang = 'en-US';
  recognition.start();
  recognition.onresult = function (event) {
    const voiceText = event.results[0][0].transcript;
    document.getElementById("message").value = voiceText;
    sendMessage();
  };
}
